# cconv
Very basic web currency converter. School project 12th grade
